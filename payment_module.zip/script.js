
let isPaymentOtpSent = false;

// Loading Animation
function showLoading(text = "Ödəniş emal olunur...") {
    const container = document.createElement("div");
    container.id = "globalLoader";
    container.style = `
        position:fixed; inset:0; background:rgba(0,0,0,0.4);
        display:flex; align-items:center; justify-content:center; z-index:9999;
    `;
    container.innerHTML = `
        <div style="background:white; padding:20px 30px; border-radius:12px; text-align:center;">
            <div class="loader" style="
                margin:auto; width:38px; height:38px;
                border:4px solid #ccc; border-top-color:#f97316;
                border-radius:50%; animation:spin 0.9s linear infinite;">
            </div>
            <p style="margin-top:12px; font-family:Arial;">${text}</p>
        </div>
        <style>
            @keyframes spin { to { transform: rotate(360deg); } }
        </style>
    `;
    document.body.appendChild(container);
}

function hideLoading() {
    const loader = document.getElementById("globalLoader");
    if (loader) loader.remove();
}

// OTP send
window.sendPaymentOtp = () => {
    const form = document.getElementById("cardForm");

    if (!form.checkValidity()) {
        alertUser("Zəhmət olmasa, kart məlumatlarını düzgün daxil edin.");
        return;
    }

    document.getElementById("cardFields").classList.add("hidden");
    document.getElementById("sendPaymentOtpBtn").classList.add("hidden");

    isPaymentOtpSent = true;

    document.getElementById("cardSubmitBtn").classList.remove("hidden");

    const otpSection = document.getElementById("paymentOtpSection");
    otpSection.innerHTML = `
        <div style="background:#fff7cc; padding:12px; border:1px solid #ffe88a; border-radius:8px; margin-top:20px;">
            <b>OTP göndərildi</b><br>
            Sınaq üçün istənilən 4–6 rəqəm daxil edə bilərsiniz. (Məs: 1234)
        </div>

        <div style="margin-top:20px;">
            <label>OTP Təsdiq Kodu</label><br>
            <input type="text" id="paymentOtp" maxlength="6"
                style="padding:12px; width:200px; margin-top:5px; font-size:20px; text-align:center;">
        </div>
    `;
};

// Payment submit — always FAIL
window.handleCardSubmission = (event) => {
    event.preventDefault();

    if (!isPaymentOtpSent) {
        alertUser("OTP kodunu göndərin.");
        return;
    }

    const otp = document.getElementById("paymentOtp")?.value;

    if (!otp || otp.length < 4 || otp.length > 6 || isNaN(otp)) {
        alertUser("Düzgün OTP kodu daxil edin (4–6 rəqəm).");
        return;
    }

    showLoading("Ödəniş yoxlanılır...");

    setTimeout(() => {
        hideLoading();

        const msg = document.getElementById("cardMessage");
        msg.classList.remove("hidden");

        msg.style = `
            margin-top:20px; padding:15px; border-radius:10px;
            background:#ffe5e5; border:1px solid #ff9a9a; color:#b30000; font-weight:bold;
        `;

        msg.innerHTML = `
            Ödəniş uğursuz oldu. Bank tərəfindən təsdiqlənmədi.<br>
            <span style="font-size:13px; color:#444;">Daha sonra yenidən cəhd edin.</span>
        `;
    }, 1500);
};
